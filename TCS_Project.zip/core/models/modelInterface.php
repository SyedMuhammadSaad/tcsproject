<?php
/**
 * ModelInterface has functions with all setter and getter
 */
namespace core\models;
/**
 * ModelInterface has pure virtual functions.
 */
interface ModelInterface
{
   
}

?>