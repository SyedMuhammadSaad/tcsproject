<p><b><i>Home Page<br>Select One of the Options</i></b></p>

<input type="radio" name="buttonchoice" value="teacher"> Teacher<br>
<input type="radio" name="buttonchoice" value="student"> Student<br>
<input type="radio" name="buttonchoice" value="course"> Course<br>
<input type="submit">