<?php
/**
 * DefaultController to display default.php
 */
namespace core\controllers;
use core\controllers\BaseController;
/**
 * DefaultController extends BaseController and uses BaseController call function
 */
class DefaultController extends BaseController
{
}

?>