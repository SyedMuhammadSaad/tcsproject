<?php
/**
 * HomeController.php makes home page
 */
namespace core\controllers;
use core\controllers\BaseController;
/**
 * HomeController calls viewmanager to call home.php
 */
class HomeController extends BaseController
{
}
