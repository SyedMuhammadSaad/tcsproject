<?php
/**
 * ControllerInterface has functions of update and delete
 */
/**
 * Namespace declared
 */
namespace core\controllers;
/**
 * ControllerInterface has pure virtual functions.
 */
interface ControllerInterface
{
}
?>