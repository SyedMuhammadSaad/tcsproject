<?php
/**
 * StudentController gets model accordingly and perform different functions.
 */
/**
 * Namespace used and declared
 */
namespace app\controllers;
use core\controllers\BaseController;
/**
 * CourseController class has CRUD functionality.
 */
class CourseController extends BaseController
{
    
}
?>