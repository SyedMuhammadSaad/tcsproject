<?php
/**
 * TeacherController gets model accordingly and perform different functions.
 */
/**
 * Namespace used and declared
 */
namespace app\controllers;
use core\controllers\BaseController;
/**
 * TeacherController class has CRUD functionality.
 */
class TeacherController extends BaseController
{
    
}
?>