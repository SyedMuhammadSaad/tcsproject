<?php
/**
 * StudentController gets model accordingly and perform different functions.
 */
/**
 * Namespace used and declared
 */
namespace app\controllers;
use core\controllers\BaseController;
/**
 * StudentController class has CRUD functionality.
 */
class StudentController extends BaseController
{
    
}
?>