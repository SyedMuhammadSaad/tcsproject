<?php
/**
 * Course Edit file
 */
echo '<b><i>Course Edit</i></b><br>';

require_once Root.d_S.'app'.d_S.'views'.d_S.'generic'.d_S.'genericEdit.php';

?>