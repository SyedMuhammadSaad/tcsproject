<?php
/**
 * Teacher List file
 */
echo '<b><i>Teacher List</i></b><br>';

require_once Root.d_S.'app'.d_S.'views'.d_S.'generic'.d_S.'genericList.php';

?>

