<p><b><i>Select One of the Options</i></b></p>

<input type="radio" name="entity" value="teacher"> Teacher<br>
<input type="radio" name="entity" value="student"> Student<br>
<input type="radio" name="entity" value="course"> Course<br>
<p><b><i>Select One of the Operation</i></b></p>
<button name="action" value="add" type="submit">Create</button>
<button name="action" value="read" type="submit">Read</button>
<button name="action" value="edit" type="submit">Update</button>
<button name="action" value="delete" type="submit">Delete</button><br>