<p><b><i>Select One of the Operation</i></b></p>

<input type="text" value="<?php echo $buttonvalue;?>" style="display:none;" name="modelname">
<button name="crud" value="add" type="submit">Create</button>
<button name="crud" value="read" type="submit">Read</button>
<button name="crud" value="edit" type="submit">Update</button>
<button name="crud" value="delete" type="submit">Delete</button><br>