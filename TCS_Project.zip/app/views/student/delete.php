<?php

echo '<b><i>Student Delete</i></b><br>';

require_once Root.d_S.'core'.d_S.'views'.d_S.'genericDelete.php';

?>