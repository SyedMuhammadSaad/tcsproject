<?php
/**
 * Config.php is configuring the database file
 */
$dbcon=array('DB_NAME'=>'tcsproject','DB_USER'=>'root','DB_PASSWORD'=>'','DB_HOST'=>'localhost','DB_TYPE'=>'mysql');