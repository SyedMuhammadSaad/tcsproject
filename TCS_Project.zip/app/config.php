<?php
/**
 * Config.php is configuring the database file
 */
/**
 * Database name
 */
define('DB_NAME', 'tcsproject');
/**
 * Database root
 */
define('DB_USER', 'root');
/**
 * Database password
 */
define('DB_PASSWORD', '');
/**
 * Database host
 */
define("DB_HOST", 'localhost');
/**
 * Database type
 */
define("DB_TYPE", 'mysql');